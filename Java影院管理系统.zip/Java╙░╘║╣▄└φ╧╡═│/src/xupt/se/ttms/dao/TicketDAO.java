package xupt.se.ttms.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import xupt.se.ttms.model.Ticket;
import xupt.se.util.DBUtil;

public class TicketDAO {
	private DBUtil conn = null;
	
	/**
	 * 输出数据库的信息到界面
	 * @return
	 */
	public List<Ticket> prinfTickets() {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		String sql = "select * from ticket";
		List<Ticket> TIList = new ArrayList<Ticket>();
		
		ResultSet rs = conn.selectTable(sql);
		try {
			while(rs.next()) {
				Ticket ti = new Ticket();
				ti.setTicket_id(rs.getString(1));
				ti.setPlay_id(rs.getString(2));
			    ti.setSchedule_id(rs.getString(3));
				ti. setSeat_id(rs.getString(4));
				ti.setTicket_price(rs.getString(5));
				
				TIList.add(ti);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return TIList;
	}
	
	/**
	 * 输出查找到的一个信息
	 * @param string_play_name
	 * @return
	 */
	public List<Ticket> prinfTicket(String string_paly_id) {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		String sql = "select * from ticket where play_id = '" + string_paly_id + "'";
		List<Ticket> TIList = new ArrayList<Ticket>();
		
		ResultSet rs = conn.selectTable(sql);
		try {
			while(rs.next()) {
				Ticket ti = new Ticket ();
				ti.setTicket_id(rs.getString(1));
				ti.setPlay_id(rs.getString(2));
				ti.setSchedule_id(rs.getString(3));
				ti.setSeat_id(rs.getString(4));
				ti.setTicket_price(rs.getString(5));
		        TIList.add(ti);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return TIList;
	}
	
	/**
	 * 添加票
	 */
	public void addTicket(String setTicket_id, String setPlay_id, String setSchedule_id, String setSeat_id
			, String setTicket_price) {
		
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		
		String sql = "insert into ticket(setTicket_id,setPlay_id,setSchedule_id,setSeat_id" +
				"setTicket_price) values('" 
				+ setTicket_id + "','" 
				+ setPlay_id + "','" 
				+ setSchedule_id + "','" 
				+ setSeat_id + "','" 
				+ setTicket_price + "')";
		
		if(conn.insertTable(sql)) {
			conn.close();
			return;
		}
	}
	
	/**
	 * 修改票
	 * 
	 */
	public void modTicket(String setTicket_id, String setPlay_id, String setSchedule_id, String setSeat_id
			, String setTicket_price) {
		
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		
		String sql = "insert into ticket(setTicket_id,setPlay_id,setSchedule_id,setSeat_id" +
				"setTicket_price) values('" 
				+ setTicket_id + "','" 
				+ setPlay_id + "','" 
				+ setSchedule_id + "','" 
				+ setSeat_id + "','" 
				+ setTicket_price + "')";
		
		if(conn.insertTable(sql)) {
			conn.close();
			return;
		}
	}
	
	
	public void delTicket(String ticket_id) {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		
		int id = Integer.parseInt(ticket_id);
		
		String sql = "delete from ticket where ticket_id = " + id;
		
		if(conn.deleteTable(sql)) {
			conn.close();
			return;
		}
	}
}