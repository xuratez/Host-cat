package xupt.se.ttms.dao;

/**
 * 管理演出厅模块-DAO层
 */

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import xupt.se.ttms.model.Studio; //调用Studio的数据层
import xupt.se.util.DBUtil; //调用数据库的工具包

public class StudioDAO {
	private DBUtil conn = null; //变量初始化
	
	/**
	 * 添加演出厅
	 * @param studio_name
	 * @param studio_row_count
	 * @param studio_col_count
	 * @param studio_introduction
	 */
	public void addStudio(String studio_name, String studio_row_count, String studio_col_count, String studio_introduction) {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		
		String sql = "insert into studio(studio_name,studio_row_count,studio_col_count," +
				"studio_introduction) values('" + studio_name + "','" + 
				studio_row_count + "','" + studio_col_count + "','" + studio_introduction + "')"; //获取自增列
		
		if(conn.insertTable(sql)) { //数据库对表的插入操作
			conn.close();
			return;
		}
	}
	
	/**
	 * 修改演出厅
	 * @param studio_name
	 * @param studio_row_count
	 * @param studio_col_count
	 * @param studio_introduction
	 */
	public void modStudio(String studio_name, String studio_row_count, String studio_col_count
			, String studio_introduction) {
		
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		
		String sql = "UPDATE studio SET studio_name = '" + studio_name +
				"', studio_row_count = '" + studio_row_count + "', studio_col_count = '" + 
				studio_col_count + "', studio_introduction = '" + studio_introduction + "'"
				+" WHERE studio_name = " + "'" + studio_name + "'"; //获取更新数据
		
		if(conn.updateTable(sql)) { //数据库对表的修改操作
			conn.close();
			return;
		}
	}
	
	/**
	 * 删除演出厅
	 * @param studio_id
	 */
	public void delStudio(String studio_id) {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		int id = Integer.parseInt(studio_id); //将演出厅的ID转化为整型
		
		String sql = "DELETE FROM studio WHERE studio_id = " + id; //获取删除数据
		
		if(conn.deleteTable(sql)) { //数据库对表的删除操作
			conn.close();
			return;
		}
	}
	
	/**
	 * 查找-把数据库中匹配的演出厅的数据输出到界面
	 * @param studio_name
	 * @return
	 */
	public List<Studio> prinfStudio(String studio_name) {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		String sql = "SELECT * FROM studio WHERE studio_name = '" + studio_name + "'"; //获取查找数据
		
		ResultSet rs = conn.selectTable(sql); //将查找结果赋值
		List<Studio> stuList = new ArrayList<Studio>(); //创建一个演出厅集合
		try {
			while(rs.next()) { //将找到演出厅数据赋值给新建的演出厅集合
				Studio stu = new Studio();
				stu.setStudio_id(rs.getString(1));
				stu.setStudio_name(rs.getString(2));
				stu.setStudio_row_count(rs.getString(3));
				stu.setStudio_col_count(rs.getString(4));
				stu.setStudio_introduction(rs.getString(5));
				stuList.add(stu);
			}
		} catch (SQLException e) { //异常捕获
			e.printStackTrace();
		}
		
		return stuList; //返回查找结果
	}
	
	/**
	 * 把数据库中的演出厅的数据输出到界面
	 * @return
	 */
	public List<Studio> prinfStudios() {
		conn = new DBUtil(); // 连接数据库
		conn.openConnection();
		String sql = "SELECT * FROM studio"; //对数据库全表扫描
		List<Studio> stuList = new ArrayList<Studio>(); //创建一个演出厅集合
		
		if (conn.selectTable(sql) != null) { //数据库中表不为空
			ResultSet rs = conn.selectTable(sql); //将查找结果赋值
			try {
				while(rs.next()) { //将演出厅数据赋值给新建的集合
					Studio stu = new Studio();
					stu.setStudio_id(rs.getString(1));
					stu.setStudio_name(rs.getString(2));
					stu.setStudio_row_count(rs.getString(3));
					stu.setStudio_col_count(rs.getString(4));
					stu.setStudio_introduction(rs.getString(5));
					stuList.add(stu);
				}
			} catch (SQLException e) { //异常捕获
				e.printStackTrace();
			}
		} else {
			System.out.println("studio表中没有数据"); //数据库中表为空
		}
		conn.close();
		
		return stuList;
	}
}
