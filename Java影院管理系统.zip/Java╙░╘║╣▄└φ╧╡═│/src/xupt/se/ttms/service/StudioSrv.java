package xupt.se.ttms.service;

/**
 * 管理演出厅模块-service层
 */

import java.util.List;

import xupt.se.ttms.dao.StudioDAO; //导入演出厅DAO层
import xupt.se.ttms.model.Studio; //导入演出厅的数据层

public class StudioSrv {
	StudioDAO stuDAO = new StudioDAO(); //新建一个StudioDAO
	
	public void addStudio(String studio_name, String studio_row_count, String studio_col_count, String studio_introduction) {
		stuDAO.addStudio(studio_name, studio_row_count, studio_col_count, studio_introduction);
	} //增加演出厅方法，调用DAO层的数据库对表数据的增加
	
	public void modStudio(String studio_name, String studio_row_count, String studio_col_count
			, String studio_introduction) {
		stuDAO.modStudio(studio_name, studio_row_count, studio_col_count, studio_introduction);
	} //修改演出厅方法，调用DAO层的数据库对表数据的修改
	
	public void delStudio(String studio_id) {
		stuDAO.delStudio(studio_id);
	} //删除演出厅方法，调用DAO层的数据库对表数据的删除
	
	public List<Studio> prinfStudio(String studio_name) {
		return stuDAO.prinfStudio(studio_name);
	} //查找演出厅方法，调用DAO层的数据库查找
	
	public List<Studio> prinfStudios() {
		return stuDAO.prinfStudios();
	} //将演出厅输出到界面的方法，调用DAO层的数据库输出
}
