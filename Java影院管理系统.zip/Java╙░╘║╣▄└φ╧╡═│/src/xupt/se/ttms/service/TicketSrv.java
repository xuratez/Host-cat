package xupt.se.ttms.service;

import java.util.List;


import xupt.se.ttms.dao.TicketDAO;

import xupt.se.ttms.model.Ticket;

public class TicketSrv {
	TicketDAO tIDAO = new  TicketDAO();
	
	public List<Ticket> prinfTickets() {
		return tIDAO.prinfTickets();
	}
	
	public List<Ticket> prinfTicket(String string_play_id) {
		return tIDAO.prinfTicket( string_play_id);
	}
	
	public void addTicket(String setTicket_id, String setPlay_id, String setSchedule_id, String setSeat_id
			, String setTicket_price) {
		
		tIDAO.addTicket( setTicket_id,  setPlay_id,  setSchedule_id,  setSeat_id
				,  setTicket_price);
	}
	
	public void  modTicket(String setTicket_id, String setPlay_id, String setSchedule_id, String setSeat_id
			, String setTicket_price) {
		tIDAO. modTicket (setTicket_id,  setPlay_id,  setSchedule_id,  setSeat_id
				,  setTicket_price);
	}
	
	public void  delTicket(String ticket_id) {
		tIDAO. delTicket( ticket_id);
	}
}


