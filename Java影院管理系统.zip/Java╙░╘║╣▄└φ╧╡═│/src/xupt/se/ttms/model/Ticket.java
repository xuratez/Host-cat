package xupt.se.ttms.model;

public class Ticket {
	private String ticket_id;
	private String play_id;
	private String seat_id;
	private String schedule_id;
	private String ticket_price;
	
	

	public String getSchedule_id() {
		return schedule_id;
	}
	public void setSchedule_id(String schedule_id) {
		this.schedule_id = schedule_id;
	}
	public String getTicket_id() {
		return ticket_id;
	}
	public void setTicket_id(String ticket_id) {
		this.ticket_id = ticket_id;
	}
	
	public String getPlay_id() {
		return play_id;
	}
	public void setPlay_id(String play_id) {
		this.play_id = play_id;
	}
	
	
	public String getSeat_id() {
		return seat_id;
	}
	public void setSeat_id(String seat_id) {
		this.seat_id = seat_id;
	}
	public String getTicket_price() {
		return ticket_price;
	}
	public void setTicket_price(String ticket_price) {
		this.ticket_price = ticket_price;
	}
	
	@Override
	public String toString() {
		return "Ticket [ticket_id=" +ticket_id + ", =" +  ",play_id =" +play_id + ", schedule_id="
				+ schedule_id + ", seat_id=" + seat_id + ",ticket_price =" + ticket_price
				+ "]";
	}
}

