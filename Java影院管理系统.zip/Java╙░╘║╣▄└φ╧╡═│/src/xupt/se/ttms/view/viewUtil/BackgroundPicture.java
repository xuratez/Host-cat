package xupt.se.ttms.view.viewUtil;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BackgroundPicture extends JFrame {
	private static final long serialVersionUID = 7032485929024193849L;
	private JPanel panel;
	
	public BackgroundPicture() {
		panel = new JPanel() {
			private static final long serialVersionUID = 1L;

			@Override
		    public void paint(Graphics g) {
		        super.paint(g);//调用父类的paint()方法
		        Graphics2D g2 = (Graphics2D)g; //强转成2D
		        ImageIcon ii1 = new ImageIcon("resource/image/bp.jpg");
		        //dimision.width是窗体的宽度，dimision.height是窗体的高度
		        g2.drawImage(ii1.getImage(), 0, 0, 1280,400, null);
			}
		};
		//窗口显示
		this.setUndecorated(true);
		panel.setPreferredSize(new Dimension(1280,400));//设置最好的大小
		this.setBackground(new Color(0, 0, 0, 0));//背景颜色
		this.setUndecorated(true);
		this.setBounds(0, 0, 1280,400);//设置窗体的偏移量
		this.add(panel);
		this.setLocationRelativeTo(null);//将窗口置于屏幕的中央
		
		this.setVisible(true);//设置可见
	}
	
	public static void main(String[] args) {
		new BackgroundPicture();
	}

}
