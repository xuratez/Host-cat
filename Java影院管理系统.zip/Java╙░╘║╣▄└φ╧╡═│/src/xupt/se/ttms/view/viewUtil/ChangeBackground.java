package xupt.se.ttms.view.viewUtil;

/**
 * 自己写的一个修改背景图片和修改主题的工具
 * @author 西邮陈冠希
 */

import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class ChangeBackground {
	//更改主题
	public static void changeTopic() {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");//windows风格
		} catch (Exception e) {
			e.printStackTrace();//打印异常
		}
	}
	
	//添加背景图片
	public static void addIcon(JFrame frame) {
		ImageIcon icon = new ImageIcon("resource/image/bp.jpg");// 背景图片  
		JLabel imgLabel = new JLabel(icon); //把背景图片显示在一个标签里面  
		frame.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));// 把背景图片添加到分层窗格的最底层作为背景  
		imgLabel.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());// 把标签的大小位置设置为图片刚好填充整个面板   
		Container contain = frame.getContentPane(); 
        ((JPanel) contain).setOpaque(false); // 把内容窗格转化为JPanel，否则不能用方法setOpaque()来使内容窗格透明     
	}	
}
