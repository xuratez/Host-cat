package xupt.se.ttms.view.viewUtil;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import xupt.se.ttms.view.systemManage.SellerMgrUI;

public class Slideshow extends JFrame {
	private static final long serialVersionUID = 1L;
	MyJPanel mp;
    int index;
    ImageIcon[] imgs = {
            new ImageIcon("resource/image/绿皮书.jpg"),
            new ImageIcon("resource/image/何以为家.jpg"),
            new ImageIcon("resource/image/小丑.jpg"),
            new ImageIcon("resource/image/雪人奇缘.jpg"),
            new ImageIcon("resource/image/半个喜剧.jpg"),
            new ImageIcon("resource/image/千与千寻.jpg"),
        };
    
    public Slideshow() {
        mp = new MyJPanel();
        this.add(mp);
        //setUndecorated(true);
        this.setBounds(100, 100, 400, 560);//设置窗体的偏移量
        this.setLocationRelativeTo(null);//将窗口置于屏幕的中央
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);//隐藏并释放窗体
        this.setTitle("海报展示");//设置标题
        this.setVisible(true);//设置可见
        Timer timer = new Timer(1000,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mp.repaint();
            }
        });
        timer.start();//定时调用
        
        this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosed(WindowEvent e) {
				new SellerMgrUI().frame.setVisible(true);
			}
        	
		});
    }
    
    public static void main(String[] args) {
        new Slideshow();
    }
    
    class MyJPanel extends JPanel{
		private static final long serialVersionUID = -6856240521257685504L;

		@Override
        public void paint(Graphics g) {
            super.paint(g);//调用父类的paint()方法
            g.drawImage(imgs[index%imgs.length].getImage(), 0, 0,this);//绘制图像
            index++;
        }
    }
}
