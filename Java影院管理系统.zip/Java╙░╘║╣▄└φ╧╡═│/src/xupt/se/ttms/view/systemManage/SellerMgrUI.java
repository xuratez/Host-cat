package xupt.se.ttms.view.systemManage;

/**
 * 售票员管理界面
 * @author 西邮陈冠希
 */

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import xupt.se.ttms.view.login.SellerLoginUI;
import xupt.se.ttms.view.schedule.SellerScheduleMgrUI;
import xupt.se.ttms.view.ticket.SellerTicketMgrUI;
import xupt.se.ttms.view.viewUtil.ChangeBackground;
import xupt.se.ttms.view.viewUtil.Slideshow;

public class SellerMgrUI {

	public JFrame frame;
	public int flag = 0;

	/**
	 *启动应用程序
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SellerMgrUI window = new SellerMgrUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建应用程序
	 */
	public SellerMgrUI() {
		initialize();
		ChangeBackground.addIcon(frame);
		ChangeBackground.changeTopic();
	}

	/**
	 * 初始化内容
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("售票员界面");//设置标题
		frame.setBounds(100, 100, 800, 600);//设置窗体的偏移量
		frame.setLocationRelativeTo(null);//将窗口置于屏幕的中央
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭应用程序
		frame.getContentPane().setLayout(null);//控件进行自由布局
		
		JLabel label = new JLabel("  售票员界面");
		label.setFont(new Font("隶书", Font.BOLD, 70));
		label.setBounds(160, 95, 581, 104);
		frame.getContentPane().add(label);//获取窗口的面板,增加label到面板中
		
		JButton button_1 = new JButton("海报展示");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Slideshow();//幻灯片演示
				frame.dispose();//关闭
			}
		});
		button_1.setFont(new Font("楷体", Font.PLAIN, 25));
		button_1.setBounds(401, 317, 183, 44);
		frame.getContentPane().add(button_1);//获取窗口的面板,增加button_1到面板中
		
		JButton button_2 = new JButton("售票");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SellerTicketMgrUI().frame.setVisible(true);//设置可见
				frame.dispose();
			}
		});
		button_2.setFont(new Font("楷体", Font.PLAIN, 25));
		button_2.setBounds(295, 379, 159, 44);
		frame.getContentPane().add(button_2);//获取窗口的面板,增加button_2到面板中
		
		JButton btnNewButton = new JButton("查询演出");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SellerScheduleMgrUI().frame.setVisible(true);//设置可见
				frame.dispose();
			}
		});
		btnNewButton.setFont(new Font("楷体", Font.PLAIN, 25));
		btnNewButton.setBounds(188, 317, 159, 44);
		frame.getContentPane().add(btnNewButton);//获取窗口的面板,增加到btnNewButton面板中
		
//		JButton button_3 = new JButton("统计销售额");
//		button_3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//			}
//		});
//		button_3.setFont(new Font("楷体", Font.PLAIN, 25));
//		button_3.setBounds(401, 378, 183, 46);
//		frame.getContentPane().add(button_3);//获取窗口的面板,增加到button_3面板中
//		button_1.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//			}
//		});
		
		JButton button_back = new JButton("返回");
		button_back.setFont(new Font("楷体", Font.PLAIN, 25));
		button_back.setBounds(650, 480, 100, 50);
		frame.getContentPane().add(button_back);//获取窗口的面板,增加到button_back面板中
		button_back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new SellerLoginUI().frame.setVisible(true);
				frame.dispose();
			}
		});
		

	}
}

