package xupt.se.ttms.view.systemManage;

/**
 * 经理管理界面
 * @author 西邮陈冠希
 */

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import xupt.se.ttms.view.login.ManagerLoginUI;
import xupt.se.ttms.view.play.PlayMgrUI;
import xupt.se.ttms.view.schedule.ScheduleMgrUI;
import xupt.se.ttms.view.stdioManage.StudioMgrUI;
import xupt.se.ttms.view.users.Users;
import xupt.se.ttms.view.viewUtil.ChangeBackground;

public class ManagerMgrUI {

	public JFrame frame;
	public int flag = 1;

	/**
	 * 启动应用程序
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerMgrUI window = new ManagerMgrUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建应用程序
	 */
	public ManagerMgrUI() {
		initialize();
		ChangeBackground.addIcon(frame);
		ChangeBackground.changeTopic();
	}
	
	/**
	 * 初始化内容
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("经理界面");//设置标题
		frame.setBounds(100, 100, 800, 600);//设置窗体的偏移量
		frame.setLocationRelativeTo(null);//将窗口置于屏幕的中央
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭应用程序
		frame.getContentPane().setLayout(null);//控件进行自由布局
		
		JLabel label = new JLabel("   经理界面");
		label.setFont(new Font("隶书", Font.BOLD, 70));
		label.setBounds(175, 95, 581, 104);
		frame.getContentPane().add(label);//获取窗口的面板,增加label到面板中
		
		JButton button = new JButton("管理剧目");
		button.setFont(new Font("楷体", Font.PLAIN, 25));
		button.setBounds(300, 200, 159, 44);
		frame.getContentPane().add(button);//获取窗口的面板,增加button到面板中
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new PlayMgrUI().frame.setVisible(true);//设置可见
				frame.dispose();
			}
		});
		
		JButton button_1 = new JButton("管理演出计划");
		button_1.setFont(new Font("楷体", Font.PLAIN, 23));
		button_1.setBounds(290, 261, 183, 44);
		frame.getContentPane().add(button_1);//获取窗口的面板,增加button_1到面板中
		button_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new ScheduleMgrUI().frame.setVisible(true);//设置可见
				frame.dispose();//关闭
			}
		});
			
		JButton button_3 = new JButton("管理演出厅");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new StudioMgrUI().frame.setVisible(true);//设置可见
				frame.dispose();//关闭
			}
		});
		button_3.setFont(new Font("楷体", Font.PLAIN, 25));
		button_3.setBounds(290, 316, 183, 44);
		frame.getContentPane().add(button_3);//获取窗口的面板,增加button_3到面板中
		
		JButton btnNewButton_1 = new JButton("管理系统用户");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Users().frame.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("楷体", Font.PLAIN, 24));
		btnNewButton_1.setBounds(290, 375, 183, 44);
		frame.getContentPane().add(btnNewButton_1);//获取窗口的面板,增加btnNewButton_1到面板中
		button_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton button_back = new JButton("返回");
		button_back.setFont(new Font("楷体", Font.PLAIN, 25));
		button_back.setBounds(650, 480, 100, 50);
		frame.getContentPane().add(button_back);//获取窗口的面板,增加button_back到面板中
		button_back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new ManagerLoginUI().frame.setVisible(true);
				frame.dispose();
			}
		});
		
	}
}
